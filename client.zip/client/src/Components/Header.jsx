import { Box, Image } from "@chakra-ui/react";
import React from "react";

function Header() {
  return (
    <>
     
        {/* <Box>


        <Image src='https://images.unsplash.com/photo-1513077202514-c511b41bd4c7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1yZWxhdGVkfDF8fHxlbnwwfHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60' alt='Dan Abramov' 
        h={"100%"}
         width={"100%"}
        />
        </Box> */}



    </>
  );
}

export default Header;
