import React from "react";

function Answer({ answer, onAnswer }) {
  return (
    <div>
      <div>
        <input name="option" type="radio" onClick={() => onAnswer(answer)} />
      </div>
      <span dangerouslySetInnerHTML={{ __html: answer }}></span>
    </div>
  );
}

export default Answer;
