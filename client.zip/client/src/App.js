
import './App.css';
import Header from './Components/Header';
// import Fetch from './Components/Fetch';
import Home from './Components/Home';

function App() {
  return (
    <div className="App" >
          <div>
          <Header/>
        <Home/>
          </div>
   
        {/* <Fetch/> */}
    </div>
  );
}

export default App;
